create or replace function rwr() 
returns void AS
$$
DECLARE
alpha double precision:=0.8;
edgecount integer:= 0;
nodecount integer:= 1;
maxid integer:=1;
maxidreal double precision:=0;
i integer:=1;
temp double precision=1;
iteration integer:= 100;
BEGIN
    DROP TABLE if exists vectorb; 
    create  TABLE vectorb (rw  integer, cl integer,weight double precision);

    --RAISE NOTICE 'i  : %  ', i;
    DROP TABLE if exists mid; 
    create  TABLE mid (rw  integer, cl integer,weight double precision);
    
    select into maxid max(GREATEST(rw, cl))  from graph;
   
    maxidreal= maxid;
	
	i=1;
	DROP TABLE if exists graphA; 
    CREATE   TABLE graphA AS TABLE graph;
    insert into vectorb(rw, cl, weight) values (i,1,1/maxidreal);
    while i<=maxid loop
           
        select into temp  sum(weight) from graphA where rw = i;
        if temp >0 then
            update graphA set weight=weight/temp where rw = i;
        end if;
        
        
        i=i+1;
    end loop;
    i=1;
    DROP TABLE if exists vectorx; 
    CREATE   TABLE vectorx AS TABLE vectorb;
    while i<=iteration loop
        RAISE NOTICE 'i  : %  ', i;
        delete from mid;
        insert into mid   (SELECT * from multiv('graphA','vectorx')); 
        delete from vectorx;
        insert into vectorx  (select * from minusv('vectorb','mid',alpha-1));
        i=i+1;
    end loop;
END;
$$ 
LANGUAGE plpgsql;

select * from rwr();
--select * from graphA;
select rw,weight from vectorx;
--\COPY vectorx(rw,weight) to rank.txt DELIMITER ',' ;


