DROP FUNCTION multiv(text,text);
create or replace function multiv( text, text) 
returns table( rw Integer,cl integer, weight double precision)  AS
$$
DECLARE
i integer:= 1;
BEGIN
    return query EXECUTE  
    'select A.rw, B.cl, SUM(A.weight * B.weight)   FROM  '||$1||' as A inner JOIN '||$2||' as B ON A.cl = B.rw GROUP BY A.rw, B.cl';
END;
$$ 
LANGUAGE plpgsql;


--select * from multiv('q' , 'q');


