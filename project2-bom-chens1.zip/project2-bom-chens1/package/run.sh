createdb graph.db

echo 'input the table into the table'
psql graph.db < input.sql

echo '***********************************************************************'

echo 'run weakly connected component '
psql graph.db < component.sql


echo '***********************************************************************'
echo 'run eigen value '
psql graph.db < dotmult.sql

psql graph.db < multiv.sql

psql graph.db < minusv.sql

psql graph.db < qrDecomposition.sql

psql graph.db < qrmethod.sql

echo 'Top 5 eigen value is shown  '
psql graph.db < lanczosso.sql
echo 'The above is the Top 5 eigen value'



echo '***********************************************************************'
echo 'run computing the number of triangle in the graph'
psql graph.db <  tri.sql ;

echo '***********************************************************************'
echo 'run computing random walk'
psql graph.db <  rwr.sql ;
echo 'The above is the random walk value for each node'

echo '************************'
sh run2.sh