CREATE OR REPLACE FUNCTION exactradius() RETURNS void AS $$
        
        DECLARE
        label boolean :=true;
        diff integer :=0;
        count1 integer:=0;
        count2 integer:=0;
        r integer :=1;
        BEGIN
        drop table if exists myradius;
        create temp table myradius(src integer, radius integer);

        drop table if exists tempr;
        create temp table tempr as 
        select src, count(*) as radius from edges group by src;

        drop table if exists tempedge;
        create temp table tempedge as table edges;
        
        while label loop
        r := r + 1;
        drop index if exists temprindex;
        create index temprindex on tempr(src);
        
        drop index if exists tempedgeindexsrc;
        drop index if exists tempedgeindexdst;
        
        create index tempedgeindexsrc on tempedge(src); 
        create index tempedgeindexdst on tempedge(dst);     

        drop table if exists nextstep;
        create temp table nextstep as 
        select distinct t1.src as src , t2.dst as dst
        from tempedge t1
        left join edges t2
        on t1.dst = t2.src;

        drop index if exists nextstepindex;
        create index nextstepindex on nextstep(src,dst);

        create temp table mergeedge(src integer, dst integer); 
        insert into mergeedge 
        select * from  
        (select * from tempr 
        union
        select * from nextstep) as shabi;

        drop index if exists merge;
        create index merge on mergeedge(src , dst);

        create temp table newr as 
        select src, count(*) as radius from mergeedge group by src;

        select count(*) from newr into count2;
        select count(*) from tempr into count1;
        raise notice 'newr is %', count2;
        raise notice 'oldr is %', count1;

        drop index if exists newrindex;
        create index newrindex on newr(src);    

        drop table  if exists updateTable;   
        create temp table updateTable as 
        select t1.src as src, t1.radius-t2.radius as difference
        from tempr t1
        left join newr t2
        on t1.src = t2.src; 

        insert into myradius
        select src, r 
        from updateTable where difference = 0 
        and src not in (select src from myradius);    


        select abs(sum(t1.radius - t2.radius)) into diff
        from tempr t1
        left join newr t2
        on t1.src = t2.src;

        if diff = 0 then
          label := false;
        end if;

        drop table if exists tempedge;
        alter table mergeedge rename to tempedge;
        drop table tempr;
        alter table newr rename to tempr;

        end loop;

        drop table if exists exactradius;
        create table exactradius as table myradius;
        drop table if exists tempr;
        drop table if exists myradius; 

        END;
        $$ LANGUAGE plpgsql;

        select exactradius();
        select * from exactradius;
