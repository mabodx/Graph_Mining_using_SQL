DROP FUNCTION dotmult(text,text);
create or replace function dotmult( text, text) 
returns table(val double precision) AS 
$$
DECLARE
i integer:= 1;
BEGIN
    return query EXECUTE  
    'select  SUM(A.weight * B.weight)   FROM  '||$1||' as A inner JOIN '||$2||' as B ON A.rw = B.rw GROUP BY A.cl, B.cl';
END;
$$ 
LANGUAGE plpgsql;

--select * from dotmult('vi' , 'v');


