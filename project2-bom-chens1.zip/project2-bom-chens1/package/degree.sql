
drop table if exists degrees;

--create table degrees(src integer, degree integer);

select src, count(dst) as degree
into degrees
from edges
group by src
order by src asc;

drop index if exists degreeindex;
create index degreeindex on degrees(src,degree);

drop table if exists degreeresult;
select degree, count(*) as num 
into degreeresult
from degrees
group by 1
order by 1 desc;

\copy degreeresult to 'degree.txt'
