drop table if exists preedge;
drop table if exists edges;
drop table if exists nodes;

create table preedge(src integer, dst integer, whatever text default null);
\copy preedge from southwomen delimiter ' '

drop table if exists edges;
drop table if exists nodes;

select src, dst into  edges from preedge order by src asc, dst asc;
--insert into  edges select dst, src from preedge order by src asc, dst asc;

drop table preedge;

drop index if exists  edgeindex; 
create index  edgeindex on  edges(src,dst);

create table  nodes (node integer);
insert into  nodes
	select distinct src from  edges;

