create or replace function mst() 
returns void AS
$$
DECLARE
edgecount integer:= 0;
nodecount integer:= 1;

BEGIN
    select into nodecount max(GREATEST(rw, cl))  from graph; 
   
		
	
    while edgecount < nodecount-1 loop
        edgecount= edgecount+1;
    end loop;
    
END;
$$ 
LANGUAGE plpgsql;

select * from mst();

