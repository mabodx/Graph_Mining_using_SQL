   UPDATE A SET weight=weight/k ;
