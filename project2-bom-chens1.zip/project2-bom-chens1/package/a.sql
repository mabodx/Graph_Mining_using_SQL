    select pagerank.src, num, (rank*0.15 + newrank) into           newpagerank
                        from pagerank
                        left join  
                        (select dst, sum(0.85 * rank/num) as newrank
                        from pagerank
                        right join edges 
                        on pagerank.src = edges.src
                        group by dst) as cal       
                        on pagerank.dst = cal.dst;
