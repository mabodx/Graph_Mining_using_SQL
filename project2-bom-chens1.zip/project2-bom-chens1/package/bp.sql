CREATE OR REPLACE FUNCTION runbp() RETURNS void AS $$
        DECLARE
	tempValue double precision;
	i integer :=0;
	totalNode integer;
	c1 double precision := 0; -- according to the papaer;
        c2 double precision :=0;        
	h double precision :=0;
        a double precision :=0;
        c double precision :=0;
        
	BEGIN
        --create table if not exists degrees (src integer, degree integer);
        --delete from degrees;
        --insert into degrees select src, count(*) from edges group by 1 order by 1 asc;
        select sum(degree) from degrees into c1;
        select sum(degree * degree) from degrees into c2;        
        c1 := c1+2;
        c2 := c2-1;
        h := sqrt((-1 * c1 + sqrt(c1*c1+4 * c2)) /(8 * c2)) * 0.8;
        a := 4 * h * h / (1- 4 * h*h);
        c := 2 * h / (1- 4 * h *h);

        raise notice 'h is %d', h;
        raise notice 'c is %f', c;
        raise notice 'a is %f', a;

        drop table if exists shabi;
        create temp table shabi(src integer, val double precision);
        insert into shabi
        select node, impor
        from bp;

	drop table if exists matrixall;
	create temp table matrixall(src integer, dst integer, val double precision);

        insert into matrixall 
        select src, dst, 1
        from edges;

        update matrixall set val = c;

        insert into matrixall
        select src, src, a*(-1)*count(dst)
        from edges
        group by src; 

        drop table if exists bppro;
        create temp table bppro(src integer, val double precision);
        insert into bppro
        select * from shabi;

        while i < 5 LOOP
        create temp table inuse(src integer, val double precision);
        
        insert into inuse
        select matrixall.src, sum(matrixall.val * coalesce(bppro.val,0))
        from matrixall
        left join bppro
        on matrixall.dst = bppro.src
        group by matrixall.src; 

        create temp table shabi2 (src integer, val double precision);
        insert into shabi2
        select shabi.src, shabi.val + coalesce(inuse.val, 0)
        from shabi
        left join inuse
        on shabi.src = inuse.src;	

        drop table shabi;
        alter table shabi2 rename to shabi; 
        drop table bppro;	
        alter table inuse rename to bppro;  
        i := i+1;
        
        raise notice 'i is %d', i;

        END LOOP;

        drop table if exists beliefpro;  
        create table beliefpro(src integer, val double precision);
        insert into beliefpro
        select * from shabi;
        drop table shabi;	
	
	END;
        $$ LANGUAGE plpgsql;

select runbp();
select * from beliefpro;

