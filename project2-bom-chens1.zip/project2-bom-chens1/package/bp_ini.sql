select src, 
case when degree < 2 then - 0.5 
	 when degree > 3 then + 0.5 
	 else 0 end as impor 
into bptemp
from degrees;

drop table if exists bp;
select node,
	coalesce(impor,0) as impor
	into bp 
	from nodes t1
	left join bptemp t2
	on t1.node = t2.src;

drop table bptemp;

drop index if exists bpindex; 
create index bpindex on bp(node);