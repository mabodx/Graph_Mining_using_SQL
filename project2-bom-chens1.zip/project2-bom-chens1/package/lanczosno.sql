CREATE OR REPLACE FUNCTION lanczosso() RETURNS void AS
$$
DECLARE
i integer:= 1;
j integer:= 1;
k integer:= 1;
maxid integer;
maxidreal double precision;
thetai double precision:=0;
alphai double precision:=0;
thetai_1 double precision:=0;
alphai_1 double precision:=0;
iteration integer:=10;
m integer:=10;
BEGIN
    select into maxid max(GREATEST(rw, cl))  from graph; --is this vmatrix?  or some other?
    maxidreal = maxid;
    
    
    RAISE NOTICE 'k: % % ', maxidreal,k;
    DROP TABLE if exists graphA; 
    create  TABLE graphA (rw  integer, cl integer,weight double precision);


    insert into  graphA select  * from graph;
    
    DROP TABLE if exists vi; 
    create  TABLE vi (rw  integer, cl integer,weight double precision);

    DROP TABLE if exists vi_1; 
    create  TABLE vi_1 (rw  integer, cl integer,weight double precision);
    
    DROP TABLE if exists v; 
    create  TABLE v (rw  integer, cl integer,weight double precision);

    DROP TABLE if exists Vmatrix; 
    create   TABLE Vmatrix (rw  integer, cl integer,weight double precision);


    DROP TABLE if exists tempv; 
    create temp TABLE tempv (rw  integer, cl integer,weight double precision);

	i=1;
    --select into theta,k pos,p from multiv('q','q',2);
    --RAISE NOTICE 'k: % % ', theta,k;
    
    --insert into v(rw,cl,weight)  (SELECT * from multiv('graphA','vi'));
	while i<=maxid loop            
	    RAISE NOTICE 'k: % ', i;
        insert into vi(rw, cl, weight) values (i,1,1/maxidreal);
        insert into vi_1(rw, cl, weight) values (i,1,1);
        i=i+1;
    end loop;
    i=1;
    while i< m loop 
        delete from v;
        insert into v(rw,cl,weight)  (SELECT * from multiv('graphA','vi'));
        select into alphai val from dotmult('vi','v');
        
        delete from tempv;
        insert into tempv (select * from minusv('v','vi_1',thetai_1));
        delete from v;
        insert into v (select * from minusv('tempv','vi',alphai));

        select into thetai sqrt(val) from dotmult('v','v'); 

        insert into Vmatrix(rw, cl, weight) values (i,i,alphai);
        if i>2 then
            insert into Vmatrix(rw, cl, weight) values (i-1,i,thetai);
            insert into Vmatrix(rw, cl, weight) values (i,i-1,thetai);
        end if ;
        
        RAISE NOTICE 'alph: % ', thetai;

        
        delete from vi_1;
        insert into vi_1 (select * from v);
        delete from vi;
        insert into vi (select rw, cl, weight/thetai from v);
        i=i+1;
    end loop;
    
    perform qrmethod();
END;
$$
Language plpgsql;


select * from lanczosso();


