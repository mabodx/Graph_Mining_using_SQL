
CREATE OR REPLACE FUNCTION CalBitOr(integer[], integer[]) RETURNS integer[] AS $$
DECLARE 
arr integer[32];
i Integer := 0;
BEGIN
arr[0] := $1[0] | $2[0];
arr[1] := $1[1] | $2[1];
arr[2] := $1[2] | $2[2];
arr[3] := $1[3] | $2[3];
arr[4] := $1[4] | $2[4];
arr[5] := $1[5] | $2[5];
arr[6] := $1[6] | $2[6];
arr[7] := $1[7] | $2[7];
arr[8] := $1[8] | $2[8];
arr[9] := $1[9] | $2[9];
arr[10] := $1[10] | $2[10];
arr[11] := $1[11] | $2[11];
arr[12] := $1[12] | $2[12];
arr[13] := $1[13] | $2[13];
arr[14] := $1[14] | $2[14];
arr[15] := $1[15] | $2[15];
arr[16] := $1[16] | $2[16];
arr[17] := $1[17] | $2[17];
arr[18] := $1[18] | $2[18];
arr[19] := $1[19] | $2[19];
arr[20] := $1[20] | $2[20];
arr[21] := $1[21] | $2[21];
arr[22] := $1[22] | $2[22];
arr[23] := $1[23] | $2[23];
arr[24] := $1[24] | $2[24];
arr[25] := $1[25] | $2[25];
arr[26] := $1[26] | $2[26];
arr[27] := $1[27] | $2[27];
arr[28] := $1[28] | $2[28];
arr[29] := $1[29] | $2[29];
arr[30] := $1[30] | $2[30];
arr[31] := $1[31] | $2[31];
RETURN arr;
END;
$$ LANGUAGE plpgsql STRICT;

        CREATE AGGREGATE MyBitOr(integer[])(
        SFUNC = CalBitOr,
        STYPE = integer[]
        );

CREATE OR REPLACE FUNCTION ini() RETURNS void AS $$
        DECLARE
        strlen integer := 0;
        i integer:=1;
        j integer:=1;
        stringNum integer:=32;
        totalNode integer:=0;
        rannum double precision:=0;
        arr integer[32];
        mypower integer:=0;
        BEGIN
        drop table if exists preindex;

        create table preindex as 
        select node, row_number() over(order by node asc) as index
        from nodes;

        drop index if exists preindexindex;
        create index preindexindex on preindex(index);

        select trunc(ln(count(*))/ln(2)) + 1 
        into strlen 
        from nodes;

        select count(*) from nodes into totalNode;
        
        drop table if exists prebitstring;

        create temp table prebitstring(index integer, val integer[32]);

        while i <= totalNode loop
            j:=0;
            while j < stringNum loop
                rannum := random() * (power(2,strlen) -1) + 1;
                mypower =   trunc(ln(rannum)/ln(2));  
                arr[j] = power(2, mypower);
                j:=j+1;
            end loop;
            insert into  prebitstring values(i, arr);
            i:=i+1;
            raise notice 'finish a run %', i;
        end loop;

        drop index if exists prebitindex;
        create index prebitindex on prebitstring(index);


        --initialize the table
        drop table if exists bitstring;
        create table bitstring as
        select t1.node as src , t2.val as val
        from preindex t1
        left join  prebitstring t2
        on t1.index = t2.index;
        

        drop index if exists bitindex;
        create index bitindex on bitstring(src);
        drop table if exists preindex;
        drop table if exists prebitstring;


        END;
        $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION radius() RETURNS void AS $$
        DECLARE
        i integer :=1;
        totalNode integer:=0;
        h integer :=1;
        hmax integer :=30;
        count double precision:=0;
        temp2size integer:=0;
        bitstringsize integer:=0;
        stringNum integer :=32;
        count2 integer :=0;

        BEGIN
        --maintain the original bitstring table
        --select count(*) from nodes2 into totalNode;

        --CREATE A TBALE TO RECORD THE RAIDUS;
        drop table if exists tempr;
        create temp table tempr as 
        select node , 0 as radius from nodes;

        --CREATE A TABLE TO RECORD THE BITSTRINGS
        drop table if exists bitstrings;
        create temp table bitstrings(src integer, val integer[32]);
        insert into bitstrings
        select * from bitstring;    
        
        while h < hmax loop
            drop table if exists bitstemp;
            
            create temp table bitstemp(src integer, val integer[32]);
            
            create index myindex on bitstrings(src);
 
            RAISE NOTICE 'ready to roll the ONE-loop';
             
            insert into bitstemp
            select t2.src, MyBitOr(t1.val)
            from bitstrings t1
            left join edges t2
            on t1.src = t2.dst
            group by t2.src;

            

            RAISE NOTICE 'ready to roll the SECOND-loop';
            
            insert into bitstemp
            select * from bitstrings;

            drop index if exists tempindex;
            create index tempindex on bitstemp(src);

            create temp table bitstemp2 as
            select t1.src, MyBitOr(CalBitOr(t1.val, t2.val)) as val
            from bitstrings t1
            left join bitstemp t2
            on t1.src = t2.src
            group by t1.src;
            
            select count(*) from bitstrings into bitstringsize;
            select count(*) from bitstemp2 into temp2size;

            raise notice 'size is %', bitstringsize;
            raise notice 'size is %', temp2size;

            drop index if exists mybittemp;
            create index mybittemp on bitstemp2(src);

            drop table if exists compare; 
            create temp table compare as 
            select b1.src as src
            from bitstrings b1
            left join 
            bitstemp2 b2
            on b1.src = b2.src
            where b1.val = b2.val;
            


            update tempr set radius = h
            where node in (select src from compare) and radius =0;
            
            drop table bitstrings;
            drop table bitstemp;
            alter table bitstemp2 rename to bitstrings;

            select count(*) into count from compare;
            select count(*) into count2 from bitstrings;
            drop table compare;
               exit when count = count2;

            h :=h+1;
        end loop;

        drop table if exists r;
        create table r as table tempr;
        drop table if exists tempr; 

        END;
        $$ LANGUAGE plpgsql;

drop table if exists newedges;
create table newedges(src integer, dst integer);

insert into newedges
select * from 
(select * from edges union select dst, src from edges) as foo;

drop table edges;
alter table newedges rename to edges;

drop index if exists newedgeindex;
create index newedgeindex on edges(src,dst);

select ini();
select radius();
select * from r;



