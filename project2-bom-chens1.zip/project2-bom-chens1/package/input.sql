/*CREATE TABLE edges (
src         integer NOT NULL,
dst         integer NOT NULL
);


COPY edges FROM '/Users/mabodx/Desktop/school/826/project1/data/web-Stanford.txt' DELIMITER ',' ;

*/








DROP TABLE if exists graph;
CREATE TABLE graph (
rw         integer NOT NULL,
cl         integer NOT NULL,
weight  double precision
);

delete from graph;
\COPY graph FROM datagraph.txt DELIMITER ',' ;

/*\COPY graph FROM  '/Users/mabodx/Desktop/school/826/project1/experiment/exp3/data/roadNet-pa/double.txt' DELIMITER ' ' ;
/*COPY graph FROM '/Users/mabodx/Desktop/school/826/project1/experiment/tridiagonal_matrix.csv' DELIMITER ',' ;*/
