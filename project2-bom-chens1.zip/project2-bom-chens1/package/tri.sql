create or replace function tri() 
returns void AS
$$
DECLARE
i integer:= 1;
temp double precision;
BEGIN
    select into temp sum(weight*weight*weight/6) from amatrix where rw=cl;
    RAISE NOTICE 'triangle num of this graph : % ', temp;
END;
$$ 
LANGUAGE plpgsql;


select * from tri();


