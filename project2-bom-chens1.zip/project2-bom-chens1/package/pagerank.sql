CREATE OR REPLACE FUNCTION runpagerank() RETURNS void AS $$
        DECLARE
                flag BOOLEAN := true;
                r INTEGER;
                m INTEGER;
                totalNode INTEGER;
                diff real;
        BEGIN
                create table IF NOT EXISTS pagerank (node integer, num integer, rank real);     
                delete from pagerank;
                
		        insert into pagerank
                select node, count(src) as num, 1.000 as rank 
                from nodes left join edges 
		        on nodes.node = edges.src 
		        group by 1;   

                select count(node) into totalNode 
                from pagerank;

                update pagerank set rank = rank/ totalNode;                 
            
                while flag LOOP
                        create table newpagerank(node integer, num integer, rank real);                            
                        
			            insert into newpagerank 
                        select pagerank.node, num, 1*0.15/totalNode + coalesce(newrank,0)
                        from pagerank
                        left join  
                        (select dst, sum(0.85 * rank/num) as newrank
                        from pagerank
                        right join edges 
                        on pagerank.node = edges.src
                        group by dst) as cal       
                        on pagerank.node = cal.dst;

                        select sum((p1.rank - p2.rank)*(p1.rank - p2.rank)) into diff
                        from pagerank as p1 
                        left join  newpagerank as p2
                        on p1.node = p2.node;
         
                        drop table pagerank;
                        ALTER TABLE newpagerank RENAME TO pagerank;

                        IF (diff) < 0.0001 THEN
                          flag := false;
                        END IF;

                END LOOP;
		 
        END;
        $$ LANGUAGE plpgsql;

select runpagerank();
drop table if EXISTS pagerankresult;
select rank as pagerank, rank() over(order by rank desc) into pagerankresult from pagerank;
\copy pagerankresult to 'pagerank.txt';