DROP FUNCTION  function minusv(text, text, real) ;
create or replace function minusv(text, text, real) 
	returns table(rw integer, cl integer, weight real) AS $$
	BEGIN
		return query EXECUTE 
		'(select coalesce(v1.rw,v2.rw),coalesce(v1.cl,v2.cl),coalesce(v1.val,0)-('||$3||')*coalesce(v2.val,0) 
		from '||$1||' as v1 full join '||$2||' as v2 on v1.rw=v2.rw)';


	END

	$$ LANGUAGE plpgsql;
