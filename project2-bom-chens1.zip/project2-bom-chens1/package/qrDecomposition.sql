CREATE OR REPLACE FUNCTION qrDecomposition() RETURNS void AS
$$
DECLARE
i integer:= 1;
j integer:= 1;
t integer:= 1;
w double precision:= 1.0;
rii double precision:=0;
rij double precision;
temp double precision;
maxid integer;
minid integer;
BEGIN
   -- RAISE NOTICE 'run qrDecomposition';
	--insert into  Qmatrix select  * from Vmatrix
	DROP TABLE if exists Q;
	create  TABLE Q (
	rw         integer NOT NULL,
	cl         integer NOT NULL,
	weight           double precision NOT NULL);

    DROP TABLE if exists Qi;
	create  TABLE Qi (
	rw         integer NOT NULL,
	cl         integer NOT NULL,
	weight           double precision NOT NULL);

	DROP TABLE if exists Qj;
	create  TABLE Qj (
	rw         integer NOT NULL,
	cl         integer NOT NULL,
	weight           double precision NOT NULL);
	
	DROP TABLE if exists R;
	create  TABLE R (
	rw	integer NOT NULL,
	cl	integer NOT NULL,
	weight	double precision NOT NULL);

	insert into  Q select  * from Vmatrix; --this matrix can change 
	
	select into maxid max(cl) from Q ;
	
	i=1;
	--RAISE NOTICE 'maxid: % ', maxid;
	
	while i <= maxid loop
		--RAISE NOTICE 'i: % ', i;
		select into rii  sqrt(sum(weight*weight))  from Q  where ( cl = i);
		--RAISE NOTICE 'rii: % ', rii;

        insert into R(rw, cl, weight) values (i,i,rii);
        
		if (rii >0) then
		    update Q set weight=weight/rii where cl = i ;		
            delete from Qi;
            insert into Qi (select * from Q where cl = i);
            
		    j = i+1;
		    --RAISE NOTICE 'j: % ', j;
		    while j<=maxid loop
		       -- RAISE NOTICE 'i j : %  %', i, j;
                select into rij  sum(Q1.weight*Q2.weight) from Q as Q1, Q as Q2 where Q1.cl = i and Q2.cl=j and Q1.rw = Q2.rw GROUP BY Q1.cl, Q2.cl;
                --RAISE NOTICE 'rij : % ', rij;
                
                delete from Qj;
                insert into Qj (select * from Q where cl = j);

                select into temp val from dotmult('qi','qj');
                
                --RAISE NOTICE 'temp : % ', temp;
                rij= temp;
                if(rij>0) then
                    insert into R(rw, cl, weight) values (i,j,rij);
                    delete from Q where cl = j;
                    insert into Q (select * from minusfirst('qj','qi',rij,j));
                end if;
                j=j+1;
		    end loop;
		end if;
		i = i+1;
	end loop;
END;
$$
Language plpgsql;

--select * from qrDecomposition();
