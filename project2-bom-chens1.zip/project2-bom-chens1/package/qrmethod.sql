CREATE OR REPLACE FUNCTION qrmethod() RETURNS void AS
$$
DECLARE
i integer:= 1;
j integer:= 1;
k integer:= 1;
maxid integer;
iteration integer:=10;
BEGIN
    DROP TABLE if exists Amatrix;
	CREATE   TABLE Amatrix AS TABLE vmatrix; --is this vmatrix?  or some other?

	DROP TABLE if exists tempQ;
    create  TABLE tempQ (
	rw	integer NOT NULL,
	cl	integer NOT NULL,
	weight	double precision NOT NULL);
	
	DROP   TABLE if exists tempR;
	create  TABLE tempR (
	rw	integer NOT NULL,
	cl	integer NOT NULL,
	weight	double precision NOT NULL);
	
	select into maxid max(GREATEST(rw, cl))  from vmatrix; --is this vmatrix?  or some other?
	
    DROP   TABLE if exists lineQ;
	create  TABLE lineQ(
	rw         integer NOT NULL,
	cl         integer NOT NULL,
	weight           double precision NOT NULL);
	
	DROP   TABLE if exists lineR;
	create  TABLE lineR (
	rw	integer NOT NULL,
	cl	integer NOT NULL,
	weight	double precision NOT NULL);
	
    i=1;
    while i<=maxid loop
        insert into lineQ(rw, cl, weight) values (i,i,1.0);
        insert into lineR(rw, cl, weight) values (i,i,1.0);
        i=i+1;
    end loop;

	
    --RAISE NOTICE 'maxid: % ', maxid;
    k=1;
    while k<iteration loop
      --  RAISE NOTICE 'k: % ', k;
            perform qrDecomposition();
            DELETE FROM Amatrix;
            insert into Amatrix select A.rw, B.cl, SUM(A.weight * B.weight)   FROM Q as A inner JOIN R as B ON A.cl = B.rw GROUP BY A.rw, B.cl;
            DELETE FROM tempQ;
            insert into tempQ select A.rw, B.cl, SUM(A.weight * B.weight)   FROM lineQ as A inner JOIN Q as B ON A.cl = B.rw GROUP BY A.rw, B.cl;
            DELETE FROM tempR;
            insert into tempR select A.rw, B.cl, SUM(A.weight * B.weight)   FROM lineR as A inner JOIN R as B ON A.cl = B.rw GROUP BY A.rw, B.cl;

            DELETE FROM lineQ;
            insert into lineQ select * from tempQ;

            DELETE FROM lineR;
            insert into lineR select * from tempR;

            
        k= k+1;
    end loop;
   -- RAISE NOTICE 'end qrmethod' ;
END;
$$
Language plpgsql;
--select * from qrmethod();


