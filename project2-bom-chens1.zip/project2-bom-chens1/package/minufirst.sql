create or replace function minusfirst(text, text, double precision, integer) 
	returns table(rw integer, cl integer, weight double precision) AS $$
	BEGIN
		return query EXECUTE 
		'(select coalesce(v1.rw,v2.rw),'||$4||' as cl,coalesce(v1.weight,0)-('||$3||')*coalesce(v2.weight,0) 
		from '||$1||' as v1 full join '||$2||' as v2 on v1.rw=v2.rw)';


	END

	$$ LANGUAGE plpgsql;

--select * from minusfirst('v','vi',1);

