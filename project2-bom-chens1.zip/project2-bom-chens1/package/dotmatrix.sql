DROP FUNCTION dotmult(text,integer);
create or replace function dotmult( text, integer) 
returns table(val double precision) AS 
$$
DECLARE
i integer:= 1;
BEGIN
    return query EXECUTE  
    'select  SUM(A.weight * B.weight)   FROM  '||$1||' as A  where A. ='||$2|| ';
END;
$$ 
LANGUAGE plpgsql;

--select * from dotmult('vi' , 'v');


