DROP FUNCTION   minusv(text, text, double precision) ;
create or replace function minusv(text, text, double precision) 
	returns table(rw integer, cl integer, weight double precision) AS $$
	BEGIN
		return query EXECUTE 
		'(select coalesce(v1.rw,v2.rw),coalesce(v1.cl,v2.cl),coalesce(v1.weight,0)-('||$3||')*coalesce(v2.weight,0) 
		from '||$1||' as v1 full join '||$2||' as v2 on v1.rw=v2.rw)';


	END

	$$ LANGUAGE plpgsql;

--select * from minusv('v','vi',1);

