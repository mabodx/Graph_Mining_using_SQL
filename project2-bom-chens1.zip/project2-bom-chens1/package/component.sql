CREATE OR REPLACE FUNCTION component() RETURNS void AS
$$
DECLARE
i integer:= 1;
j integer:= 1;
k integer:= 1;
w real:= 1.0; 
maxid integer;
BEGIN
    
DROP   TABLE if exists items;
create table if not exists items(
  id int ,
  component_id int
);

select into maxid max(GREATEST(rw, cl))  from graph; 
i=1;
while i<=maxid loop
    insert into items(id, component_id) values (i,i);
    i=i+1;
end loop;

DROP   TABLE if exists components_to_merge;
create table if not exists components_to_merge(
  component1 int,
  component2 int);

DROP   TABLE if exists new_components;
create table if not exists new_components(
  source int,
  target int);

j=1;
while j>0 loop
  delete from components_to_merge;
  insert into components_to_merge
           ( select distinct t1.component_id c1, t2.component_id c2
            from graph
            join items t1
            on graph.rw = t1.id
            join items t2
            on graph.cl = t2.id
            where t1.component_id != t2.component_id);


SELECT into j count(*) FROM (SELECT 1 FROM components_to_merge limit 1) AS t;
--RAISE NOTICE 'j: % ', j;


insert into components_to_merge
select component2, component1 from components_to_merge; -- ensure symmetricity

delete from new_components;
insert into new_components (select component1 as source, min(component2)  as target
      from components_to_merge
      group by source);


update items
set component_id = least(component_id, new_components.target)
from new_components 
where new_components.source = component_id  ;


end loop;

select into k count(distinct component_id)  from items;
RAISE NOTICE 'number of the component: % ', k;
END;
$$
Language plpgsql;

select * from component();
select * from items;



