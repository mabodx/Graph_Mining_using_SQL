CREATE OR REPLACE FUNCTION lanczosso() RETURNS void AS
$$
DECLARE
i integer:= 1;
j integer:= 1;
k integer:= 1;
maxid integer;
maxidreal double precision;
thetai double precision:=0;
alphai double precision:=0;
thetai_1 double precision:=0;
alphai_1 double precision:=0;
e double precision:=1;
iteration integer:=10;
m integer:=6;
tempa double precision;
tempb double precision;
fn_1 double precision=1;
fn_2 double precision=0;
fn double precision;
flag integer;
isso integer:=1;
BEGIN
    select into maxid max(GREATEST(rw, cl))  from graph; --is this vmatrix?  or some other?
    maxidreal = maxid;
    
    
    --RAISE NOTICE 'k: % % ', maxidreal,k;
    DROP TABLE if exists graphA; 
    create  TABLE graphA (rw  integer, cl integer,weight double precision);


    insert into  graphA select  * from graph;
    
    DROP TABLE if exists vi; 
    create  TABLE vi (rw  integer, cl integer,weight double precision);

    DROP TABLE if exists vi_1; 
    create  TABLE vi_1 (rw  integer, cl integer,weight double precision);
    
    DROP TABLE if exists v; 
    create  TABLE v (rw  integer, cl integer,weight double precision);

   
    DROP TABLE if exists Vmatrix; 
    create   TABLE Vmatrix (rw  integer, cl integer,weight double precision);

    DROP TABLE if exists fvalue; 
    create   TABLE fvalue (rw  integer, weight double precision);
    insert into fvalue(rw,  weight) values (-1,0);
    insert into fvalue(rw,  weight) values (0,1);
    

    DROP TABLE if exists tempv; 
    create  TABLE tempv (rw  integer, cl integer,weight double precision);
    DROP TABLE if exists tempq; 
    create  TABLE tempq (rw  integer, cl integer,weight double precision);
    DROP TABLE if exists r; 
    create  TABLE r (rw  integer, cl integer,weight double precision);
    
	i=1;
    --select into theta,k pos,p from multiv('q','q',2);
    --RAISE NOTICE 'k: % % ', theta,k;
    
    --insert into v(rw,cl,weight)  (SELECT * from multiv('graphA','vi'));
	while i<=maxid loop            
	    
        insert into vi(rw, cl, weight) values (i,1,1/maxidreal);
        insert into vi_1(rw, cl, weight) values (i,1,0);
        i=i+1;
    end loop;

    CREATE temp  TABLE bigv AS TABLE vi; 


    i=1;
    
    while i< m loop 
       -- RAISE NOTICE 'i: % ', i;
        flag = 0;
        delete from v;
        insert into v(rw,cl,weight)  (SELECT * from multiv('graphA','vi'));
        select into alphai val from dotmult('vi','v');
        

        delete from tempv;
        if(thetai_1>0) then
           insert into tempv (select * from minusv('v','vi_1',thetai_1));
        end if;
        delete from v;
        insert into v (select * from minusv('tempv','vi',alphai));

        select into thetai sqrt(val) from dotmult('v','v'); 
        
        insert into Vmatrix(rw, cl, weight) values (i,i,alphai);
        if i>2 then
            insert into Vmatrix(rw, cl, weight) values (i-1,i,thetai);
            insert into Vmatrix(rw, cl, weight) values (i,i-1,thetai);
        end if ;

        perform qrmethod(); -- open when u want to test
        j=1;
         
        fn = alphai*fn_1 -thetai*fn_2; 
        if isso =1 then 
        while j < i loop
            select into tempa thetai*weight from lineq where rw = i and cl = j;
            if tempa < e*fn then
                delete from tempq;
                insert into tempq select * from lineq where lineq.cl = j;
                delete from r;
                insert  into  r (select * from multiv('bigv', 'tempq'));             
                select into tempb val from dotmult('r','v');

                delete from tempv;
                insert into tempv (select * from minusv('v','r',tempb));
                delete from v;
                insert into v (select * from tempv);
                flag = 1;
            end if;
            j=j+1;
        end loop;
        if flag>0 then
            select into thetai sqrt(val) from dotmult('v','v'); 
        end if;

        if thetai <0.0000001 then
            i = m+1;
        end if;
        --RAISE NOTICE 'aldph: % ', thetai;
        end if;
        fn_2 =fn_1;
        fn_1 = fn;
        
        delete from vi_1;
        insert into vi_1 (select * from v);
        delete from vi;
        insert into vi (select rw, cl+1, weight/thetai from v);
        insert into bigv (select * from v);
        thetai_1 =thetai;
        i=i+1;
    end loop;
    
    perform qrmethod();--open when u want to test
END;
$$
Language plpgsql;


select * from lanczosso();

select weight from amatrix where amatrix.rw =amatrix.cl order by amatrix.weight DESC;

