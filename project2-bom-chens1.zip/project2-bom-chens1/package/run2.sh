createdb graph4
echo 'Create the table into the table'
psql graph4 < createTable.sql

echo 'Run Node Distribution'
psql graph4 < degree.sql

echo 'Run Plot degree'
echo "set term png; set logscale x; set logscale y; set output'degree.png'; plot 'degree.txt' with linespoints" | gnuplot 

echo 'Run PageRank'
psql graph4 < pagerank.sql

echo 'Run Plot PageRank'
echo "set term png; set logscale x; set logscale y; set output'PageRank.png'; plot 'degree.txt' with linespoints" | gnuplot 

echo 'Belief Propogation'
psql graph4 < bp_ini.sql
psql graph4 < bp.sql

echo 'Radius Estimation'
psql graph4 < radius.sql

echo 'Innovation: Radius Exact Radius'
psql graph4 < exactradius.sql

